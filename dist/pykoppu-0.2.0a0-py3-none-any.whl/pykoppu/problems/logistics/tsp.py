"""
TSP problem module.
"""
