# KOPPU (K-dimensional Organoid Probabilistic Processing Unit)

**Target Platform:** OaaS (Organoid as a Service) / `koppu.io`
**SDK:** `pykoppu`

KOPPU is a project designed to interface with organoid processing units. This repository contains the `pykoppu` SDK.
