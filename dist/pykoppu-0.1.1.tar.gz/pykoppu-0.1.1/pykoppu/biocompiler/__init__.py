"""
Biocompiler module.
"""
