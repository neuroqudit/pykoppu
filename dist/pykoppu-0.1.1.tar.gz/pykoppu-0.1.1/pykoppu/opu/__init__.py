"""
OPU (Organoid Processing Unit) module.
"""
