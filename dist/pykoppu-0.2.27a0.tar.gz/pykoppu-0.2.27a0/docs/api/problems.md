# Problems API

## Base Class
::: pykoppu.problems.base.PUBOProblem

## Graph Problems
::: pykoppu.problems.graph.maxcut.MaxCut

## Logistics Problems
::: pykoppu.problems.logistics.knapsack.Knapsack

## Finance Problems
::: pykoppu.problems.finance.portfolio.PortfolioOptimization
