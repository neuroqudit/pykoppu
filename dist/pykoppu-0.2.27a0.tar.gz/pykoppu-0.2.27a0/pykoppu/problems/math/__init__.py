"""
Math Problems Package Initialization.
"""

from .sat3 import SAT3

__all__ = ["SAT3"]
