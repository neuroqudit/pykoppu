"""
Graph Problems Package Initialization.
"""

from .maxcut import MaxCut

__all__ = ["MaxCut"]
