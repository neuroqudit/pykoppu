# OOS (Organoid Operating System)

The OOS layer manages the compilation and execution of problems on the OPU.

## Process

::: pykoppu.oos.Process

## Result

::: pykoppu.oos.SimulationResult
