# Electrophysiology API

::: pykoppu.electrophysiology.base.ElectrophysiologyDriver
::: pykoppu.electrophysiology.cpu.CPUDriver
::: pykoppu.electrophysiology.connect
