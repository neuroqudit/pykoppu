# Electrophysiology API

::: pykoppu.electrophysiology.base.ElectrophysiologyDriver
::: pykoppu.electrophysiology.brian2.Brian2Driver
::: pykoppu.electrophysiology.connect
