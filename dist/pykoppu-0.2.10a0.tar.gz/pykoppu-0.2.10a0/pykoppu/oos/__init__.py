"""
OOS Package Initialization.
"""

from .process import Process
from .result import SimulationResult

__all__ = ["Process"]
