"""
Logistics Problems Package Initialization.
"""

from .knapsack import Knapsack

__all__ = ["Knapsack"]
