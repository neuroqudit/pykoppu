# OPU (Organoid Processing Unit)

The OPU layer handles the low-level simulation of organoid physics.

## Device

::: pykoppu.opu.OPU

## Kernel

::: pykoppu.opu.Kernel
