# Problems API

::: pykoppu.problems.base.PUBOProblem
::: pykoppu.problems.graph.maxcut.MaxCut
